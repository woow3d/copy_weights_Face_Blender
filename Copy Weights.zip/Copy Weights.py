bl_info = {
    "name": "Copy Weights Tools",
    "author": "Abdulrahman Baggash (Simple Code)",
    "version": (1, 1, 0),
    "blender": (4, 0, 0),
    "location": "Edit Mode > Right Click Menu or Mesh > Weights > Copy Weights Tools",
    "description": "Copy vertex group weights from the active face to other selected faces with blend options.",
    "warning": "",
    "wiki_url": "https://simplecode.dev",
    "category": "Mesh",
}


import bpy
import bmesh


def get_weight_safe(vg, index):
    try:
        return vg.weight(index)
    except RuntimeError:
        return 0.0


def copy_weights_from_active_face(use_average=True, only_nonzero_groups=False, blend_factor=1.0):
    """
    Copy vertex group weights from active face to other selected faces.
    """
    obj = bpy.context.object
    if not obj or obj.type != 'MESH':
        print("Active object is not a mesh.")
        return {'CANCELLED'}

    if bpy.context.mode != 'EDIT_MESH':
        print("Must be in Edit Mode.")
        return {'CANCELLED'}

    bm = bmesh.from_edit_mesh(obj.data)
    bm.faces.ensure_lookup_table()
    bm.verts.ensure_lookup_table()

    # Find active face
    active_face = None
    for elem in reversed(bm.select_history):
        if isinstance(elem, bmesh.types.BMFace) and elem.select:
            active_face = elem
            break
    if not active_face and bm.faces.active and bm.faces.active.select:
        active_face = bm.faces.active

    if not active_face:
        print("No active face selected.")
        return {'CANCELLED'}

    selected_faces = [f for f in bm.faces if f.select]
    if len(selected_faces) <= 1:
        print("Need more than one selected face.")
        return {'CANCELLED'}

    ref_verts = active_face.verts
    ref_vert_indices = [v.index for v in ref_verts]
    me = obj.data
    vgroups = obj.vertex_groups
    if not vgroups:
        print("Object has no vertex groups.")
        return {'CANCELLED'}

    # Collect source weights
    weights = {}
    if use_average:
        for vg in vgroups:
            total_weight = 0.0
            count = 0
            for vert in ref_verts:
                w = get_weight_safe(vg, vert.index)
                if w > 0.0 or not only_nonzero_groups:
                    total_weight += w
                    count += 1
            weights[vg.index] = (total_weight / count) if count > 0 else 0.0
    else:
        first_vert_idx = ref_vert_indices[0]
        for vg in vgroups:
            weights[vg.index] = get_weight_safe(vg, first_vert_idx)

    if only_nonzero_groups:
        weights = {k: v for k, v in weights.items() if abs(v) > 0.0001}

    if not weights:
        print("No weights found to copy.")
        return {'CANCELLED'}

    target_verts = set()
    for face in selected_faces:
        if face is active_face:
            continue
        for vert in face.verts:
            target_verts.add(vert.index)

    if not target_verts:
        print("No target vertices found.")
        return {'CANCELLED'}

    prev_mode = obj.mode
    bpy.ops.object.mode_set(mode='OBJECT')
    try:
        for group_index, weight_value in weights.items():
            vg = vgroups[group_index]
            for vert_index in target_verts:
                current_weight = get_weight_safe(vg, vert_index)
                new_weight = (
                    current_weight * (1 - blend_factor) + weight_value * blend_factor
                    if blend_factor < 1.0 else weight_value
                )
                vg.add([vert_index], new_weight, 'REPLACE')

    except Exception as e:
        print(f"Error applying weights: {e}")
        return {'CANCELLED'}
    finally:
        bpy.ops.object.mode_set(mode=prev_mode)
        bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)

    return {'FINISHED'}


# === Operators ===

class MESH_OT_copy_weights_average(bpy.types.Operator):
    """Copy average vertex weights from active face to selected faces"""
    bl_idname = "mesh.copy_weights_average"
    bl_label = "Copy Weights (Average)"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        result = copy_weights_from_active_face(use_average=True)
        if result == {'FINISHED'}:
            self.report({'INFO'}, "Weights copied successfully (Average)")
        return result


class MESH_OT_copy_weights_first_vertex(bpy.types.Operator):
    """Copy vertex weights from first vertex of active face to selected faces"""
    bl_idname = "mesh.copy_weights_first_vertex"
    bl_label = "Copy Weights (First Vertex)"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        result = copy_weights_from_active_face(use_average=False)
        if result == {'FINISHED'}:
            self.report({'INFO'}, "Weights copied successfully (First Vertex)")
        return result


class MESH_OT_copy_weights_nonzero_only(bpy.types.Operator):
    """Copy only non-zero weights from active face to selected faces"""
    bl_idname = "mesh.copy_weights_nonzero_only"
    bl_label = "Copy Weights (Non-Zero Only)"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        result = copy_weights_from_active_face(use_average=True, only_nonzero_groups=True)
        if result == {'FINISHED'}:
            self.report({'INFO'}, "Weights copied successfully (Non-Zero Only)")
        return result


class MESH_OT_copy_weights_custom_blend(bpy.types.Operator):
    """Blend custom percentage of weights from active face"""
    bl_idname = "mesh.copy_weights_custom_blend"
    bl_label = "Copy Weights (Custom Blend)"
    bl_options = {'REGISTER', 'UNDO'}

    blend_factor: bpy.props.FloatProperty(
        name="Blend Factor",
        description="Blend new weights with existing (0.0 = keep old, 1.0 = replace)",
        min=0.0, max=1.0, default=0.5
    )

    def execute(self, context):
        result = copy_weights_from_active_face(
            use_average=True,
            only_nonzero_groups=False,
            blend_factor=self.blend_factor
        )
        if result == {'FINISHED'}:
            self.report({'INFO'}, f"Weights blended successfully ({int(self.blend_factor*100)}%)")
        return result


# === Menu ===

class MESH_MT_copy_weights_menu(bpy.types.Menu):
    """Copy Weights Menu"""
    bl_idname = "MESH_MT_copy_weights_menu"
    bl_label = "Copy Weights Tools"

    def draw(self, context):
        layout = self.layout
        layout.operator("mesh.copy_weights_average", icon='MOD_VERTEX_WEIGHT')
        layout.operator("mesh.copy_weights_first_vertex", icon='VERTEXSEL')
        layout.operator("mesh.copy_weights_nonzero_only", icon='X')
        layout.separator()
        layout.operator("mesh.copy_weights_custom_blend", icon='MOD_MASK')


def menu_func(self, context):
    if context.mode == 'EDIT_MESH' and context.object.type == 'MESH':
        self.layout.separator()
        self.layout.menu("MESH_MT_copy_weights_menu", icon='MOD_VERTEX_WEIGHT')


# === Register ===

def register():
    bpy.utils.register_class(MESH_OT_copy_weights_average)
    bpy.utils.register_class(MESH_OT_copy_weights_first_vertex)
    bpy.utils.register_class(MESH_OT_copy_weights_nonzero_only)
    bpy.utils.register_class(MESH_OT_copy_weights_custom_blend)
    bpy.utils.register_class(MESH_MT_copy_weights_menu)
    bpy.types.VIEW3D_MT_edit_mesh_context_menu.append(menu_func)
    bpy.types.VIEW3D_MT_edit_mesh_weights.append(menu_func)


def unregister():
    bpy.utils.unregister_class(MESH_OT_copy_weights_average)
    bpy.utils.unregister_class(MESH_OT_copy_weights_first_vertex)
    bpy.utils.unregister_class(MESH_OT_copy_weights_nonzero_only)
    bpy.utils.unregister_class(MESH_OT_copy_weights_custom_blend)
    bpy.utils.unregister_class(MESH_MT_copy_weights_menu)
    bpy.types.VIEW3D_MT_edit_mesh_context_menu.remove(menu_func)
    bpy.types.VIEW3D_MT_edit_mesh_weights.remove(menu_func)


if __name__ == "__main__":
    register()
